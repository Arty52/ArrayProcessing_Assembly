//Author information
//  Author name: Art Grichine
//  Author email: ArtGrichine@gmail.com
//Course information
//  Course number: CPSC240
//  Assignment number: 5
//  Due date: 2014-April-08
//Project information
//  Project title: Statistics (Assignment 5)
//  Purpose: Preform basic statistical computation on a set of numbers entered by a user. Statistical computation 
//	    includes: geometric length, arithmetic mean, harmonic mean, sort and median calculations. This project is made up of
//	    multiple modules (15 - 7 C++, 8 Assembly X64-86 NASM). All modules follow the standard C++ calling convention. Values
//	    are only returned on rax (long) or xmm0 (double) and all modules function completely independantly of one another.
//  Status: No known errors
//  Project files: ArrayProcessingDriver.cpp, ArrayProcessingMain.asm, ArrayProcessingInputArray.asm, computemean.cpp,
//                 computelength.cpp, outputarray.asm, sumarray.asm, squarearray.asm, reciprocalarray.asm, computemedian.cpp, 
//	           harmonicmean.asm, quicksort.cpp, recursivequick.cpp, partition.cpp, swap.asm, debug.inc, debug.asm
//Module information
//  This module's call name: computemedian
//  Language: C++
//  Date last modified: 2014-April-02
//  Purpose: Find and return the median value in an array of values.
//  File name: computemedian.cpp
//  Status: No known errors.
//  Future enhancements: None planned
//Translator information (Tested in Linux (Ubuntu) shell)
//  Gnu compiler: g++ -c -m64 -Wall -l computemedian.lis -o computemedian.o computemedian.cpp
//References and credits
//  References: CSUF/Professor Floyd Holliday: http://holliday.ecs.fullerton.edu
//  Module: this module is standard C++ language
//Format information
//  Page width: 132 columns
//  Begin comments: 81
//  Optimal print specification: Landscape, 8 points or smaller, monospace, 8 1⁄2x11 paper
//Preconditions:
//	1. rdi --> starting address array
//	2. rsi --> # of elements in the array
//Postconditions:
//	2. median is in xmm0
//===== Begin code area ===========================================================================================================
//

extern "C" double computemedian(double myarray[], long validnumbers);		//myarray[] --> rdi, validnumbers --> rsi

double computemedian(double myarray[], long validnumbers)
{
    //Allocate new array and sort it. Median must be calculated form sorted array
    double* arSort = new double[validnumbers];					//to not change array we allocate new storage that
										//  we may use to store and manipulate our array
    for (int i = 0; i < validnumbers; ++i)					//copy the array we recieve into new allocated array
        arSort[i] = myarray[i];							

    for (int i = validnumbers - 1; i > 0; --i) 					//sort array by comparing one value to the next and
    {										//  swapping values if one is less than the other
        for (int j = 0; j < i; ++j) 
	{
            if (arSort[j] > arSort[j+1]) 
	    {
                double arTemp = arSort[j];
                arSort[j] = arSort[j+1];
                arSort[j+1] = arTemp;
            }
        }
    }

    // Find median
    double arMedian = 0.0;							//initialize variable to store the array median

    if ((validnumbers % 2) == 0)						//median in an even array is the mean of the two 
        arMedian = (arSort[validnumbers/2] + arSort[(validnumbers/2) - 1])/2.0;	//  values found in the middle of the sorted array
    else
        arMedian = arSort[validnumbers/2];					//median in an odd array is just the value found in
										//  the middle
    delete [] arSort;								//delete allocated storage of memory. new = delete
    return arMedian;								//median value in --> xmm0
}
//
//========== End of program computemedian.cpp =====================================================================================
