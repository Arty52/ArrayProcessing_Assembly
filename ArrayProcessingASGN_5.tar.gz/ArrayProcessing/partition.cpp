//Author information
//  Author name: Art Grichine
//  Author email: ArtGrichine@gmail.com
//Course information
//  Course number: CPSC240
//  Assignment number: 5
//  Due date: 2014-April-08
//Project information
//  Project title: Statistics (Assignment 5)
//  Purpose: Preform basic statistical computation on a set of numbers entered by a user. Statistical computation 
//	    includes: geometric length, arithmetic mean, harmonic mean, sort and median calculations. This project is made up of
//	    multiple modules (15 - 7 C++, 8 Assembly X64-86 NASM). All modules follow the standard C++ calling convention. Values
//	    are only returned on rax (long) or xmm0 (double) and all modules function completely independantly of one another.
//  Status: No known errors
//  Project files: ArrayProcessingDriver.cpp, ArrayProcessingMain.asm, ArrayProcessingInputArray.asm, computemean.cpp,
//                 computelength.cpp, outputarray.asm, sumarray.asm, squarearray.asm, reciprocalarray.asm, computemedian.cpp, 
//	           harmonicmean.asm, quicksort.cpp, recursivequick.cpp, partition.cpp, swap.asm, debug.inc, debug.asm
//Module information
//  This module's call name: partition
//  Language: C++
//  Date last modified: 2014-April-02
//  Purpose: This module partitions the array of data and calls a 'swap' function from an assembly file to quickly swap the data
//  File name: partition.cpp
//  Status: No known errors.
//  Future enhancements: None planned
//Translator information (Tested in Linux (Ubuntu) shell)
//  Gnu compiler: g++ -c -m64 -Wall -l partition.lis -o partition.o partition.cpp
//References and credits
//  References: CSUF/Professor Floyd Holliday: http://holliday.ecs.fullerton.edu
//  Module: this module is standard C++ language
//Format information
//  Page width: 132 columns
//  Begin comments: 65
//  Optimal print specification: Landscape, 8 points or smaller, monospace, 8 1⁄2x11 paper
//Preconditions:
//	1. Pointer to input is passed in parameter 1
//	2. Starting index of where data will be sorted
//	3. Ending index of where data will be sorted
//Postconditions:
//	2. The index 'r' is returned to the caller
//===== Begin code area ===========================================================================================================
//
extern "C" long int partition(double* input, int p, int r);

extern "C" void swap(double* x, double* y);			//external .asm subprogram that swaps two values with given address

extern "C" long int partition(double* input, int p, int r)
{
	int pivot = input[r];					//pivot point will indicate the partition divide

	while ( p < r )						//run loop through as long as second index is larger than the first
	{
		while ( input[p] < pivot )			//check lower side of the partition against the pivot point
			p++;					//move the lower index up

		while ( input[r] > pivot )			//check higher side of the partition against the pivot point
			r--;					//move the higher index up

		if ( input[p] == input[r] )			//if the index's value is equal to the other, increase lower index
			p++;
		else if ( p < r )				//if swap needs to be preformed, call the 'swap' subprogram
		{
			swap( &input[p], &input[r] );
		}
	}

	return r;						//return the upper index
}
//
//========== End of program partition.cpp =========================================================================================
