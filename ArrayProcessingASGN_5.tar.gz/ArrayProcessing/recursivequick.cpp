//Author information
//  Author name: Art Grichine
//  Author email: ArtGrichine@gmail.com
//Course information
//  Course number: CPSC240
//  Assignment number: 5
//  Due date: 2014-April-08
//Project information
//  Project title: Statistics (Assignment 5)
//  Purpose: Preform basic statistical computation on a set of numbers entered by a user. Statistical computation 
//	    includes: geometric length, arithmetic mean, harmonic mean, sort and median calculations. This project is made up of
//	    multiple modules (15 - 7 C++, 8 Assembly X64-86 NASM). All modules follow the standard C++ calling convention. Values
//	    are only returned on rax (long) or xmm0 (double) and all modules function completely independantly of one another.
//  Status: No known errors
//  Project files: ArrayProcessingDriver.cpp, ArrayProcessingMain.asm, ArrayProcessingInputArray.asm, computemean.cpp,
//                 computelength.cpp, outputarray.asm, sumarray.asm, squarearray.asm, reciprocalarray.asm, computemedian.cpp, 
//	           harmonicmean.asm, quicksort.cpp, recursivequick.cpp, partition.cpp, swap.asm, debug.inc, debug.asm
//Module information
//  This module's call name: recursivequick
//  Language: C++
//  Date last modified: 2014-April-02
//  Purpose: This module recursively calls itself until data is sorted from one index to another
//  File name: recursivequick.cpp
//  Status: No known errors.
//  Future enhancements: None planned
//Translator information (Tested in Linux (Ubuntu) shell)
//  Gnu compiler: g++ -c -m64 -Wall -l recursivequick.lis -o recursivequick.o recursivequick.cpp
//References and credits
//  References: CSUF/Professor Floyd Holliday: http://holliday.ecs.fullerton.edu
//  Module: this module is standard C++ language
//Format information
//  Page width: 132 columns
//  Begin comments: 65
//  Optimal print specification: Landscape, 8 points or smaller, monospace, 8 1⁄2x11 paper
//Preconditions:
//	1. Pointer to input is passed in parameter 1
//	2. Starting index of where data will be sorted
//	3. Ending index of where data will be sorted
//Postconditions:
//	2. Data are sorted
//===== Begin code area ===========================================================================================================
//
extern "C" void recursivequick(double* input, int p, int r);

extern "C" long int partition(double* input, int p, int r);	//external C++ program used to partitioning array of data and swap

extern "C" void recursivequick(double* input, int p, int r)	
{
	if ( p < r )						//if the first index < second index we preform a recursive sort
	{
		int j = partition(input, p, r);			//partition data for quick efficient sort O(n*logn) vs O(n^2)
		recursivequick(input, p, j-1);			//recursive call against itself moving index down from end
		recursivequick(input, j+1, r);			//recursive call against itself moving index up from beginning
	}	
}
//
//========== End of program recursivequick.cpp ====================================================================================
