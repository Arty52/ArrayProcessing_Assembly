//Author information
//  Author name: Art Grichine
//  Author email: ArtGrichine@gmail.com
//Course information
//  Course number: CPSC240
//  Assignment number: 5
//  Due date: 2014-April-08
//Project information
//  Project title: Statistics (Assignment 5)
//  Purpose: Preform basic statistical computation on a set of numbers entered by a user. Statistical computation 
//	    includes: geometric length, arithmetic mean, harmonic mean, sort and median calculations. This project is made up of
//	    multiple modules (15 - 7 C++, 8 Assembly X64-86 NASM). All modules follow the standard C++ calling convention. Values
//	    are only returned on rax (long) or xmm0 (double) and all modules function completely independantly of one another.
//  Status: No known errors
//  Project files: ArrayProcessingDriver.cpp, ArrayProcessingMain.asm, ArrayProcessingInputArray.asm, computemean.cpp,
//                 computelength.cpp, outputarray.asm, sumarray.asm, squarearray.asm, reciprocalarray.asm, computemedian.cpp, 
//	           harmonicmean.asm, quicksort.cpp, recursivequick.cpp, partition.cpp, swap.asm, debug.inc, debug.asm
//Module information
//  This module's call name: ArrayProcessingDriver.  This module is invoked by the user.
//  Language: C++
//  Date last modified: 2014-April-02
//  Purpose: This module is the top level driver: it will call ArrayProcessingMain()
//  File name: ArrayProcessingDriver.cpp
//  Status: No known errors.
//  Future enhancements: None planned
//Translator information (Tested in Linux (Ubuntu) shell)
//  Gnu compiler: g++ -c -m64 -Wall -l ArrayProcessingDriver.lis -o ArrayProcessingDriver.o ArrayProcessingDriver.cpp
//  Gnu linker:   g++ -m64 -o ArrayProcessing.out ArrayProcessingDriver.o ArrayProcessingMain.o debug.o ArrayProcessingInputArray.o
//                outputarray.o sumarray.o computemean.o squarearray.o computelength.o harmonicmean.o reciprocalarray.o 
//                computemedian.o quicksort.o recursivequick.o partition.o swap.o
//  Execute:      ./ArrayProcessing.out
//References and credits
//  References: CSUF/Professor Floyd Holliday: http://holliday.ecs.fullerton.edu
//  Module: this module is standard C++ language
//Format information
//  Page width: 132 columns
//  Begin comments: N/A
//  Optimal print specification: Landscape, 8 points or smaller, monospace, 81⁄2x11 paper
//
//===== Begin code area ===========================================================================================================
//
#include <stdio.h>
#include <stdint.h>

extern "C" double ArrayProcessingMain(); 

int main()
{
  double return_code = -99.99;
  
  return_code = ArrayProcessingMain();
  printf("%s%1.9lf.","The driver received this value: ",return_code);
  printf("\n%s","Now the driver will return control to the operating system.\n");

return 0;
}
//
//========== End of program ArrayProcessingDriver.cpp =============================================================================
