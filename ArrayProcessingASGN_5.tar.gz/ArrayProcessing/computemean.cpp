//Author information
//  Author name: Art Grichine
//  Author email: ArtGrichine@gmail.com
//Course information
//  Course number: CPSC240
//  Assignment number: 5
//  Due date: 2014-April-08
//Project information
//  Project title: Statistics (Assignment 5)
//  Purpose: Preform basic statistical computation on a set of numbers entered by a user. Statistical computation 
//	    includes: geometric length, arithmetic mean, harmonic mean, sort and median calculations. This project is made up of
//	    multiple modules (15 - 7 C++, 8 Assembly X64-86 NASM). All modules follow the standard C++ calling convention. Values
//	    are only returned on rax (long) or xmm0 (double) and all modules function completely independantly of one another.
//  Status: No known errors
//  Project files: ArrayProcessingDriver.cpp, ArrayProcessingMain.asm, ArrayProcessingInputArray.asm, computemean.cpp,
//                 computelength.cpp, outputarray.asm, sumarray.asm, squarearray.asm, reciprocalarray.asm, computemedian.cpp, 
//	           harmonicmean.asm, quicksort.cpp, recursivequick.cpp, partition.cpp, swap.asm, debug.inc, debug.asm
//Module information
//  This module's call name: computemean
//  Language: C++
//  Date last modified: 2014-April-02
//  Purpose: This module calls 'sumarray'. Once 'sumarray' returns its value this module divides the sum by valid numbers in the 
//	     array and produces the arithmetic mean of the array. The module returns the mean value.
//  File name: computemean.cpp
//  Status: No known errors.
//  Future enhancements: None planned
//Translator information (Tested in Linux (Ubuntu) shell)
//  Gnu compiler: g++ -c -m64 -Wall -l computemean.lis -o computemean.o computemean.cpp
//References and credits
//  References: CSUF/Professor Floyd Holliday: http://holliday.ecs.fullerton.edu
//  Module: this module is standard C++ language
//Format information
//  Page width: 132 columns
//  Begin comments: 73
//  Optimal print specification: Landscape, 8 points or smaller, monospace, 81⁄2x11 paper
//Preconditions:
//	1. rdi --> starting address
//	2. rsi --> # of elements in the array
//Postconditions:
//	2. xmm0 --> arithmetic mean
//===== Begin code area ===========================================================================================================
//

extern "C" double sumarray(double myarray[], long validnumbers); 	//myarray[] --> rdi, validnumbers --> rsi. Return in xmm0

extern "C" double computemean(double myarray[], long validnumbers);	//myarray[] --> rdi, validnumbers --> rsi. Return in xmm0

double computemean(double myarray[], long validnumbers)
{
  double sum = sumarray(myarray, validnumbers);				//sumarray.asm will calculate the sum of the array & return
									//  to this subprogram. Value of sum is in xmm0 & will be
									//  stored in the 'sum' double we initialized above
  double mean = sum/validnumbers;					//This subprogram divides the .asm summation with the #'s
  return mean;								//  of user input and returns the mean to the parent
}
//
//========== End of program computemedian.cpp =====================================================================================
