//Author information
//  Author name: Art Grichine
//  Author email: ArtGrichine@gmail.com
//Course information
//  Course number: CPSC240
//  Assignment number: 5
//  Due date: 2014-April-08
//Project information
//  Project title: Statistics (Assignment 5)
//  Purpose: Preform basic statistical computation on a set of numbers entered by a user. Statistical computation 
//	    includes: geometric length, arithmetic mean, harmonic mean, sort and median calculations. This project is made up of
//	    multiple modules (15 - 7 C++, 8 Assembly X64-86 NASM). All modules follow the standard C++ calling convention. Values
//	    are only returned on rax (long) or xmm0 (double) and all modules function completely independantly of one another.
//  Status: No known errors
//  Project files: ArrayProcessingDriver.cpp, ArrayProcessingMain.asm, ArrayProcessingInputArray.asm, computemean.cpp,
//                 computelength.cpp, outputarray.asm, sumarray.asm, squarearray.asm, reciprocalarray.asm, computemedian.cpp, 
//	           harmonicmean.asm, quicksort.cpp, recursivequick.cpp, partition.cpp, swap.asm, debug.inc, debug.asm
//Module information
//  This module's call name: quicksort
//  Language: C++
//  Date last modified: 2014-April-02
//  Purpose: This module partitions the array of data and calls a 'swap' function from an assembly file to quickly swap the data
//  File name: quicksort.cpp
//  Status: No known errors.
//  Future enhancements: None planned
//Translator information (Tested in Linux (Ubuntu) shell)
//  Gnu compiler: g++ -c -m64 -Wall -l quicksort.lis -o quicksort.o quicksort.cpp
//References and credits
//  References: CSUF/Professor Floyd Holliday: http://holliday.ecs.fullerton.edu
//  Module: this module is standard C++ language
//Format information
//  Page width: 132 columns
//  Begin comments: 65
//  Optimal print specification: Landscape, 8 points or smaller, monospace, 8 1⁄2x11 paper
//Preconditions:
//	1. Pointer to input is passed in parameter 1
//	2. Starting index of where data will be sorted
//	3. Ending index of where data will be sorted
//Postconditions:
//	2. The index 'r' is returned to the caller
//===== Begin code area ===========================================================================================================
//
extern "C" void quicksort(double* input, int p, int r);

extern "C" void recursivequick(double* input, int p, int r);	//external C++ subprogram used in this function for recursion

extern "C" void quicksort(double* input, int p, int r)		//main driver for sorting subprograms, sorts array
{
	recursivequick(input, p, r-1);				//call sorting program
}
//
//========== End of program quicksort.cpp =========================================================================================
